package com.junitchk;

public class Calculate {

	// Method under test
    int add(int a, int b) {
        return a + b;
    }
}
