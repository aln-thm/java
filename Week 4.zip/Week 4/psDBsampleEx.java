package com.dbeg;

public class psDBsampleEx {

}
