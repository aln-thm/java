package com.exceleg;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import java.io.*;

public class ExcelWrite2Eg {
	
	static String sarr[][]= {{"aaa","qqq","zzz"},{"www","eee","rrr"},{"ccc","sss","hhh"}};

	public static void main(String[] args) {
		try {
			//create workbook
			Workbook wbook= new XSSFWorkbook();
			
			//create a new sheet
			Sheet st = wbook.createSheet("First Sheet");
			
			for(int i = 0; i<sarr.length;++i) {
				//create row
				Row row = st.createRow(i);
				for (int j=0; j<sarr[0].length;j++) {
					Cell cell = row.createCell(j);
					cell.setCellValue(sarr[i][j]);
					// create cell,and set value to cell
					System.out.println("Writing the element"+ sarr[i][j]+ "To Excel");
				}
				
				System.out.println();
			}
			FileOutputStream fos = new FileOutputStream("../../secondexcel.xlsx");
			
			wbook.write(fos);
		}
		catch (Exception et) {
			et.printStackTrace();
		}
	}
}
